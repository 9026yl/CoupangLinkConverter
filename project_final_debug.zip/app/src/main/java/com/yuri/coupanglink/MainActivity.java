package com.yuri.coupanglink;

import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.view.View;
import android.widget.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {

    private static final String HOST = "https://api-gateway.coupang.com";
    private static final String PATH = "/v2/providers/affiliate_open_api/apis/openapi/v1/deeplink";

    EditText accessKey, secretKey, subId, urlInput;
    TextView status, result;
    Button saveKeys, editKeysButton, pasteButton, convertButton, shareButton;
    LinearLayout keyPanel;
    SharedPreferences prefs;
    String lastResult = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.yuri.coupanglink.R.layout.activity_main);

        prefs = getSharedPreferences("partner_keys", MODE_PRIVATE);

        keyPanel = findViewById(R.id.keyPanel);
        accessKey = findViewById(R.id.accessKey);
        secretKey = findViewById(R.id.secretKey);
        subId = findViewById(R.id.subId);
        urlInput = findViewById(R.id.urlInput);
        status = findViewById(R.id.status);
        result = findViewById(R.id.result);
        saveKeys = findViewById(R.id.saveKeys);
        editKeysButton = findViewById(R.id.editKeysButton);
        pasteButton = findViewById(R.id.pasteButton);
        convertButton = findViewById(R.id.convertButton);
        shareButton = findViewById(R.id.shareButton);

        accessKey.setText(prefs.getString("access", ""));
        secretKey.setText(prefs.getString("secret", ""));
        subId.setText(prefs.getString("subid", ""));

        saveKeys.setOnClickListener(v -> saveKeys());
        editKeysButton.setOnClickListener(v -> showKeyPanel());
        pasteButton.setOnClickListener(v -> pasteClipboard());
        convertButton.setOnClickListener(v -> convert());
        shareButton.setOnClickListener(v -> shareLastResult());

        refreshKeyPanel();
        handleSharedText(getIntent());
    }

    private void refreshKeyPanel() {
        boolean saved = !prefs.getString("access", "").isEmpty()
                && !prefs.getString("secret", "").isEmpty();

        keyPanel.setVisibility(saved ? View.GONE : View.VISIBLE);
        editKeysButton.setVisibility(saved ? View.VISIBLE : View.GONE);
    }

    private void showKeyPanel() {
        keyPanel.setVisibility(View.VISIBLE);
        editKeysButton.setVisibility(View.GONE);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleSharedText(intent);
    }

    private void handleSharedText(Intent intent) {
        if (Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            String shared = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (shared != null) {
                String extracted = extractUrl(shared);
                urlInput.setText(extracted != null ? extracted : shared);
            }
        }
    }

    private String extractUrl(String text) {
        if (text == null) return null;
        String[] parts = text.split("\\s+");
        for (String p : parts) {
            if (p.startsWith("http://") || p.startsWith("https://")) return p.trim();
        }
        return null;
    }

    private void saveKeys() {
        String a = accessKey.getText().toString().trim();
        String s = secretKey.getText().toString().trim();
        String sub = subId.getText().toString().trim();

        if (a.isEmpty() || s.isEmpty()) {
            Toast.makeText(this, "Access Key와 Secret Key를 입력해 주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        prefs.edit()
                .putString("access", a)
                .putString("secret", s)
                .putString("subid", sub)
                .apply();

        Toast.makeText(this, "API 설정을 저장했습니다.", Toast.LENGTH_SHORT).show();
        refreshKeyPanel();
    }

    private void pasteClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
            CharSequence cs = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (cs != null) {
                String text = cs.toString();
                String extracted = extractUrl(text);
                urlInput.setText(extracted != null ? extracted : text);
            }
        }
    }

    private void convert() {
        String a = prefs.getString("access", "").trim();
        String s = prefs.getString("secret", "").trim();
        String sub = prefs.getString("subid", "").trim();
        String url = urlInput.getText().toString().trim();

        if (a.isEmpty() || s.isEmpty()) {
            status.setText("먼저 API 설정을 저장해 주세요.");
            showKeyPanel();
            return;
        }
        if (url.isEmpty()) {
            status.setText("변환할 쿠팡 링크를 입력해 주세요.");
            return;
        }
        if (!isCoupangUrl(url)) {
            status.setText("쿠팡 링크인지 확인해 주세요.");
            return;
        }

        status.setText("변환 중...");
        result.setText("");
        result.setTextColor(0xFF111111);
        shareButton.setVisibility(View.GONE);
        convertButton.setEnabled(false);

        new Thread(() -> {
            try {
                String resolvedUrl = resolveCoupangUrl(url);
                String converted = callDeeplinkApi(a, s, sub, resolvedUrl);
                runOnUiThread(() -> {
                    lastResult = converted;
                    result.setText(converted);
                    result.setTextColor(0xFF111111);
                    status.setText("변환 완료 · 링크가 자동 복사되었습니다.");
                    copyToClipboard(converted);
                    shareButton.setVisibility(View.VISIBLE);
                    convertButton.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("변환 실패: " + e.getMessage());
                    result.setText("");
                    result.setTextColor(0xFF888888);
                    convertButton.setEnabled(true);
                });
            }
        }).start();
    }

    private boolean isCoupangUrl(String raw) {
        try {
            URL u = new URL(raw);
            String h = u.getHost().toLowerCase(Locale.ROOT);
            return h.equals("coupang.com") || h.endsWith(".coupang.com");
        } catch (Exception e) {
            return false;
        }
    }

    private String resolveCoupangUrl(String rawUrl) throws Exception {
        URL first = new URL(rawUrl);
        String host = first.getHost().toLowerCase(Locale.ROOT);

        // 일반 상품 URL이면 그대로 사용
        if (!host.equals("link.coupang.com")) {
            return cleanProductUrl(rawUrl);
        }

        // link.coupang.com 단축 링크는 실제 쿠팡 상품 페이지까지 따라감
        URL current = first;
        for (int i = 0; i < 10; i++) {
            HttpURLConnection conn = (HttpURLConnection) current.openConnection();
            conn.setInstanceFollowRedirects(false);
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(12000);
            conn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 "
                + "(KHTML, like Gecko) Chrome/138.0 Mobile Safari/537.36"
            );
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml");

            int code = conn.getResponseCode();

            if (code >= 300 && code < 400) {
                String location = conn.getHeaderField("Location");
                conn.disconnect();

                if (location == null || location.trim().isEmpty()) {
                    throw new IOException("단축링크의 이동 주소를 찾지 못했습니다.");
                }

                current = new URL(current, location);
                continue;
            }

            String finalUrl = current.toString();

            // 리다이렉트가 아니라 HTML에서 canonical URL을 주는 경우도 확인
            if (code >= 200 && code < 300) {
                String html = "";
                try {
                    html = readAll(conn.getInputStream());
                } catch (Exception ignored) {}

                String canonical = extractCanonicalUrl(html);
                if (canonical != null && canonical.contains("coupang.com")) {
                    finalUrl = canonical;
                }
            }

            conn.disconnect();

            if (isRealCoupangProductUrl(finalUrl)) {
                return cleanProductUrl(finalUrl);
            }

            // 마지막 URL이 coupang.com 이지만 상품 URL이 아니면 그대로 시도
            URL finalParsed = new URL(finalUrl);
            String finalHost = finalParsed.getHost().toLowerCase(Locale.ROOT);
            if (finalHost.equals("coupang.com") || finalHost.endsWith(".coupang.com")) {
                return finalUrl;
            }

            throw new IOException("실제 쿠팡 상품 주소로 이동하지 못했습니다.");
        }

        throw new IOException("단축링크 이동 횟수가 너무 많습니다.");
    }

    private boolean isRealCoupangProductUrl(String url) {
        try {
            URL u = new URL(url);
            String host = u.getHost().toLowerCase(Locale.ROOT);
            return (host.equals("coupang.com") || host.endsWith(".coupang.com"))
                    && u.getPath() != null
                    && u.getPath().contains("/vp/products/");
        } catch (Exception e) {
            return false;
        }
    }

    private String cleanProductUrl(String rawUrl) {
        try {
            URL u = new URL(rawUrl);
            String host = u.getHost().toLowerCase(Locale.ROOT);

            if (!(host.equals("coupang.com") || host.endsWith(".coupang.com"))) {
                return rawUrl;
            }

            String path = u.getPath();
            if (path == null || !path.contains("/vp/products/")) {
                return rawUrl;
            }

            // Deeplink 변환에 불필요한 기존 제휴/추적 파라미터는 제거하고
            // 상품 옵션 식별에 필요한 itemId / vendorItemId만 유지
            String query = u.getQuery();
            String itemId = getQueryParam(query, "itemId");
            String vendorItemId = getQueryParam(query, "vendorItemId");

            StringBuilder clean = new StringBuilder();
            clean.append("https://www.coupang.com").append(path);

            boolean firstParam = true;
            if (itemId != null && !itemId.isEmpty()) {
                clean.append(firstParam ? "?" : "&")
                     .append("itemId=").append(urlEncode(itemId));
                firstParam = false;
            }
            if (vendorItemId != null && !vendorItemId.isEmpty()) {
                clean.append(firstParam ? "?" : "&")
                     .append("vendorItemId=").append(urlEncode(vendorItemId));
            }

            return clean.toString();
        } catch (Exception e) {
            return rawUrl;
        }
    }

    private String getQueryParam(String query, String wanted) {
        if (query == null || query.isEmpty()) return null;

        String[] pairs = query.split("&");
        for (String pair : pairs) {
            int eq = pair.indexOf('=');
            String key = eq >= 0 ? pair.substring(0, eq) : pair;
            String value = eq >= 0 ? pair.substring(eq + 1) : "";

            try {
                key = URLDecoder.decode(key, "UTF-8");
                value = URLDecoder.decode(value, "UTF-8");
            } catch (Exception ignored) {}

            if (wanted.equals(key)) return value;
        }
        return null;
    }

    private String urlEncode(String value) {
        try {
            return URLEncoder.encode(value, "UTF-8");
        } catch (Exception e) {
            return value;
        }
    }

    private String extractCanonicalUrl(String html) {
        if (html == null || html.isEmpty()) return null;

        String lower = html.toLowerCase(Locale.ROOT);
        int pos = 0;

        while (true) {
            int link = lower.indexOf("<link", pos);
            if (link < 0) return null;

            int end = lower.indexOf(">", link);
            if (end < 0) return null;

            String tag = html.substring(link, end + 1);
            String tagLower = tag.toLowerCase(Locale.ROOT);

            if (tagLower.contains("canonical")) {
                int href = tagLower.indexOf("href=");
                if (href >= 0) {
                    int start = href + 5;
                    while (start < tag.length() && Character.isWhitespace(tag.charAt(start))) start++;

                    if (start < tag.length()) {
                        char quote = tag.charAt(start);
                        if (quote == '"' || quote == '\\'') {
                            int close = tag.indexOf(quote, start + 1);
                            if (close > start) {
                                return tag.substring(start + 1, close)
                                        .replace("&amp;", "&");
                            }
                        }
                    }
                }
            }

            pos = end + 1;
        }
    }

    private String callDeeplinkApi(String access, String secret, String sub, String coupangUrl) throws Exception {
        String signedDate = utcSignedDate();
        String message = signedDate + "POST" + PATH;
        String signature = hmacSha256(secret, message);

        String authorization =
                "CEA algorithm=HmacSHA256, access-key=" + access +
                ", signed-date=" + signedDate +
                ", signature=" + signature;

        StringBuilder body = new StringBuilder();
        body.append("{\"coupangUrls\":[\"").append(jsonEscape(coupangUrl)).append("\"]");
        if (sub != null && !sub.trim().isEmpty()) {
            body.append(",\"subId\":\"").append(jsonEscape(sub.trim())).append("\"");
        }
        body.append("}");

        HttpURLConnection conn = (HttpURLConnection) new URL(HOST + PATH).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Authorization", authorization);
        conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");

        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(bytes);
        }

        int code = conn.getResponseCode();
        InputStream input = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(input);

        if (code < 200 || code >= 300) {
            String msg = extractJsonString(response, "rMessage");
            if (msg == null) msg = extractJsonString(response, "message");
            throw new IOException(msg != null ? msg : "HTTP " + code);
        }

        String shorten = extractJsonString(response, "shortenUrl");
        if (shorten != null && !shorten.isEmpty()) return shorten;

        String landing = extractJsonString(response, "landingUrl");
        if (landing != null && !landing.isEmpty()) return landing;

        throw new IOException("쿠팡 API 응답에서 변환 링크를 찾지 못했습니다.");
    }

    private String utcSignedDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd'T'HHmmss'Z'", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        return sdf.format(new Date());
    }

    private String hmacSha256(String secret, String message) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        byte[] digest = mac.doFinal(message.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) sb.append(String.format(Locale.US, "%02x", b & 0xff));
        return sb.toString();
    }

    private String jsonEscape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    private String extractJsonString(String json, String key) {
        if (json == null) return null;
        String needle = "\"" + key + "\"";
        int k = json.indexOf(needle);
        if (k < 0) return null;
        int colon = json.indexOf(':', k + needle.length());
        if (colon < 0) return null;
        int q1 = json.indexOf('"', colon + 1);
        if (q1 < 0) return null;

        StringBuilder out = new StringBuilder();
        boolean esc = false;
        for (int i = q1 + 1; i < json.length(); i++) {
            char c = json.charAt(i);
            if (esc) {
                switch (c) {
                    case '"': out.append('"'); break;
                    case '\\': out.append('\\'); break;
                    case '/': out.append('/'); break;
                    case 'b': out.append('\b'); break;
                    case 'f': out.append('\f'); break;
                    case 'n': out.append('\n'); break;
                    case 'r': out.append('\r'); break;
                    case 't': out.append('\t'); break;
                    default: out.append(c);
                }
                esc = false;
            } else if (c == '\\') {
                esc = true;
            } else if (c == '"') {
                return out.toString();
            } else {
                out.append(c);
            }
        }
        return null;
    }

    private void copyToClipboard(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("쿠팡 파트너스 링크", text));
        }
    }

    private void shareLastResult() {
        if (lastResult == null || lastResult.isEmpty()) return;
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, lastResult);
        startActivity(Intent.createChooser(send, "파트너스 링크 공유"));
    }
}
