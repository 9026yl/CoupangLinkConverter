쿠팡 파트너스 링크 변환기 - 안드로이드 앱 소스

앱 기능
- 최초 1회 Access Key / Secret Key 저장
- 남이 준 coupang.com 링크 붙여넣기
- 쿠팡 파트너스 Deeplink API 호출
- 변환된 shortenUrl 자동 클립보드 복사
- 카카오톡 등으로 바로 공유
- 브라우저/쿠팡 앱에서 '공유' → 이 앱으로 링크 전달 가능

중요
이 프로젝트에는 실제 Access Key / Secret Key가 들어 있지 않습니다.
앱을 설치한 뒤 첫 화면에 직접 입력합니다.

보안
키는 Android SharedPreferences(앱 전용 저장소)에 저장됩니다.
개인용으로만 쓰세요. 루팅/디버깅/백업 환경에서는 추출 가능성이 있습니다.

APK 생성
AndroidIDE 같은 안드로이드 개발 앱에서 이 폴더를 Existing Project로 열어
Gradle Sync 후 Run/Quick Run을 누르면 debug APK를 빌드 및 설치할 수 있습니다.

필요한 Android 프로젝트 설정
- compileSdk 34
- targetSdk 34
- minSdk 26
- Android Gradle Plugin 8.2.2
