package com.yuri.coupanglink;

import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.view.View;
import android.widget.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {

    private static final String HOST = "https://api-gateway.coupang.com";
    private static final String PATH = "/v2/providers/affiliate_open_api/apis/openapi/v1/deeplink";

    EditText accessKey, secretKey, subId, urlInput;
    TextView status, result;
    Button saveKeys, editKeysButton, pasteButton, convertButton, shareButton;
    LinearLayout keyPanel;
    SharedPreferences prefs;
    String lastResult = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.yuri.coupanglink.R.layout.activity_main);

        prefs = getSharedPreferences("partner_keys", MODE_PRIVATE);

        keyPanel = findViewById(R.id.keyPanel);
        accessKey = findViewById(R.id.accessKey);
        secretKey = findViewById(R.id.secretKey);
        subId = findViewById(R.id.subId);
        urlInput = findViewById(R.id.urlInput);
        status = findViewById(R.id.status);
        result = findViewById(R.id.result);
        saveKeys = findViewById(R.id.saveKeys);
        editKeysButton = findViewById(R.id.editKeysButton);
        pasteButton = findViewById(R.id.pasteButton);
        convertButton = findViewById(R.id.convertButton);
        shareButton = findViewById(R.id.shareButton);

        accessKey.setText(prefs.getString("access", ""));
        secretKey.setText(prefs.getString("secret", ""));
        subId.setText(prefs.getString("subid", ""));

        saveKeys.setOnClickListener(v -> saveKeys());
        editKeysButton.setOnClickListener(v -> showKeyPanel());
        pasteButton.setOnClickListener(v -> pasteClipboard());
        convertButton.setOnClickListener(v -> convert());
        shareButton.setOnClickListener(v -> shareLastResult());

        refreshKeyPanel();
        handleSharedText(getIntent());
    }

    private void refreshKeyPanel() {
        boolean saved = !prefs.getString("access", "").isEmpty()
                && !prefs.getString("secret", "").isEmpty();

        keyPanel.setVisibility(saved ? View.GONE : View.VISIBLE);
        editKeysButton.setVisibility(saved ? View.VISIBLE : View.GONE);
    }

    private void showKeyPanel() {
        keyPanel.setVisibility(View.VISIBLE);
        editKeysButton.setVisibility(View.GONE);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleSharedText(intent);
    }

    private void handleSharedText(Intent intent) {
        if (Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            String shared = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (shared != null) {
                String extracted = extractUrl(shared);
                urlInput.setText(extracted != null ? extracted : shared);
            }
        }
    }

    private String extractUrl(String text) {
        if (text == null) return null;
        String[] parts = text.split("\\s+");
        for (String p : parts) {
            if (p.startsWith("http://") || p.startsWith("https://")) return p.trim();
        }
        return null;
    }

    private void saveKeys() {
        String a = accessKey.getText().toString().trim();
        String s = secretKey.getText().toString().trim();
        String sub = subId.getText().toString().trim();

        if (a.isEmpty() || s.isEmpty()) {
            Toast.makeText(this, "Access Key와 Secret Key를 입력해 주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        prefs.edit()
                .putString("access", a)
                .putString("secret", s)
                .putString("subid", sub)
                .apply();

        Toast.makeText(this, "API 설정을 저장했습니다.", Toast.LENGTH_SHORT).show();
        refreshKeyPanel();
    }

    private void pasteClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
            CharSequence cs = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (cs != null) {
                String text = cs.toString();
                String extracted = extractUrl(text);
                urlInput.setText(extracted != null ? extracted : text);
            }
        }
    }

    private void convert() {
        String a = prefs.getString("access", "").trim();
        String s = prefs.getString("secret", "").trim();
        String sub = prefs.getString("subid", "").trim();
        String url = urlInput.getText().toString().trim();

        if (a.isEmpty() || s.isEmpty()) {
            status.setText("먼저 API 설정을 저장해 주세요.");
            showKeyPanel();
            return;
        }
        if (url.isEmpty()) {
            status.setText("변환할 쿠팡 링크를 입력해 주세요.");
            return;
        }
        if (!isCoupangUrl(url)) {
            status.setText("쿠팡 링크인지 확인해 주세요.");
            return;
        }

        status.setText("변환 중...");
        result.setText("");
        result.setTextColor(0xFF111111);
        shareButton.setVisibility(View.GONE);
        convertButton.setEnabled(false);

        new Thread(() -> {
            try {
                String converted = callDeeplinkApi(a, s, sub, url);
                runOnUiThread(() -> {
                    lastResult = converted;
                    result.setText(converted);
                    result.setTextColor(0xFF111111);
                    status.setText("변환 완료 · 링크가 자동 복사되었습니다.");
                    copyToClipboard(converted);
                    shareButton.setVisibility(View.VISIBLE);
                    convertButton.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("변환 실패: " + e.getMessage());
                    result.setText("");
                    result.setTextColor(0xFF888888);
                    convertButton.setEnabled(true);
                });
            }
        }).start();
    }

    private boolean isCoupangUrl(String raw) {
        try {
            URL u = new URL(raw);
            String h = u.getHost().toLowerCase(Locale.ROOT);
            return h.equals("coupang.com") || h.endsWith(".coupang.com");
        } catch (Exception e) {
            return false;
        }
    }

    private String callDeeplinkApi(String access, String secret, String sub, String coupangUrl) throws Exception {
        String signedDate = utcSignedDate();
        String message = signedDate + "POST" + PATH;
        String signature = hmacSha256(secret, message);

        String authorization =
                "CEA algorithm=HmacSHA256, access-key=" + access +
                ", signed-date=" + signedDate +
                ", signature=" + signature;

        StringBuilder body = new StringBuilder();
        body.append("{\"coupangUrls\":[\"").append(jsonEscape(coupangUrl)).append("\"]");
        if (sub != null && !sub.trim().isEmpty()) {
            body.append(",\"subId\":\"").append(jsonEscape(sub.trim())).append("\"");
        }
        body.append("}");

        HttpURLConnection conn = (HttpURLConnection) new URL(HOST + PATH).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Authorization", authorization);
        conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");

        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(bytes);
        }

        int code = conn.getResponseCode();
        InputStream input = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(input);

        if (code < 200 || code >= 300) {
            String msg = extractJsonString(response, "rMessage");
            if (msg == null) msg = extractJsonString(response, "message");

            String debug = response;
            if (debug != null && debug.length() > 1500) {
                debug = debug.substring(0, 1500) + "...";
            }

            throw new IOException(
                "HTTP " + code
                + "\n메시지: " + (msg != null ? msg : "(없음)")
                + "\n원본응답: " + (debug == null ? "(없음)" : debug)
            );
        }

        String shorten = extractJsonString(response, "shortenUrl");
        if (shorten != null && !shorten.isEmpty()) return shorten;

        String landing = extractJsonString(response, "landingUrl");
        if (landing != null && !landing.isEmpty()) return landing;

        String rCode = extractJsonString(response, "rCode");
        String rMessage = extractJsonString(response, "rMessage");

        String debug = response;
        if (debug != null && debug.length() > 1500) {
            debug = debug.substring(0, 1500) + "...";
        }

        throw new IOException(
            "응답코드: " + (rCode == null ? "(없음)" : rCode)
            + "\n메시지: " + (rMessage == null ? "(없음)" : rMessage)
            + "\n원본응답: " + (debug == null ? "(없음)" : debug)
        );
    }

    private String utcSignedDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd'T'HHmmss'Z'", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        return sdf.format(new Date());
    }

    private String hmacSha256(String secret, String message) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        byte[] digest = mac.doFinal(message.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) sb.append(String.format(Locale.US, "%02x", b & 0xff));
        return sb.toString();
    }

    private String jsonEscape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private String readAll(InputStream in) throws IOException {
        if (in == null) return "";
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    private String extractJsonString(String json, String key) {
        if (json == null) return null;
        String needle = "\"" + key + "\"";
        int k = json.indexOf(needle);
        if (k < 0) return null;
        int colon = json.indexOf(':', k + needle.length());
        if (colon < 0) return null;
        int q1 = json.indexOf('"', colon + 1);
        if (q1 < 0) return null;

        StringBuilder out = new StringBuilder();
        boolean esc = false;
        for (int i = q1 + 1; i < json.length(); i++) {
            char c = json.charAt(i);
            if (esc) {
                switch (c) {
                    case '"': out.append('"'); break;
                    case '\\': out.append('\\'); break;
                    case '/': out.append('/'); break;
                    case 'b': out.append('\b'); break;
                    case 'f': out.append('\f'); break;
                    case 'n': out.append('\n'); break;
                    case 'r': out.append('\r'); break;
                    case 't': out.append('\t'); break;
                    default: out.append(c);
                }
                esc = false;
            } else if (c == '\\') {
                esc = true;
            } else if (c == '"') {
                return out.toString();
            } else {
                out.append(c);
            }
        }
        return null;
    }

    private void copyToClipboard(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("쿠팡 파트너스 링크", text));
        }
    }

    private void shareLastResult() {
        if (lastResult == null || lastResult.isEmpty()) return;
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, lastResult);
        startActivity(Intent.createChooser(send, "파트너스 링크 공유"));
    }
}
